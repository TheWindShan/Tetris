#include "HelloWorldScene.h"

USING_NS_CC;
USING_NS_CC_EXT;

const float SCALE = 40.0f/63;

struct Tetris
{
    int box[4][4];
    int color;
    int next_type;
};

struct Tetris tetris[CELL_TYPE] =
{
    {{
        {1,0,0,0},          //  口       2 type 0
        {1,0,0,0},          //  口       2
        {1,0,0,0},          //  口     1 3 1 1
        {1,0,0,0}}, 1, 1    //  口       2
    },
    {{
        {0,0,0,0},          //          type 1
        {0,0,0,0},          //
        {0,0,0,0},          //  口口口口
        {1,1,1,1}}, 1, 0    //
    },
    {{
        {0,0,0,0},          //          type 2
        {0,0,0,0},          //
        {1,0,0,0},          //  口
        {1,1,1,0}}, 2, 3    //  口 口 口
    },
    {{
        {0,0,0,0},          //          type 3
        {1,1,0,0},          //  口 口
        {1,0,0,0},          //  口
        {1,0,0,0}}, 2, 4    //  口
    },
    {{
        {0,0,0,0},          //          type 4
        {0,0,0,0},          //
        {1,1,1,0},          //  口 口 口
        {0,0,1,0}}, 2, 5    //        口
    },
    {{
        {0,0,0,0},          //          type 5
        {0,1,0,0},          //     口
        {0,1,0,0},          //     口
        {1,1,0,0}}, 2, 2    //  口 口
    },
    {{
        {0,0,0,0},          //          type 6
        {0,0,0,0},          //
        {0,0,1,0},          //        口
        {1,1,1,0}}, 3, 7    //  口 口 口
    },
    {{
        {0,0,0,0},          //          type 7
        {1,0,0,0},          //  口
        {1,0,0,0},          //  口
        {1,1,0,0}}, 3, 8    //  口 口
    },
    {{
        {0,0,0,0},          //          type 8
        {0,0,0,0},          //
        {1,1,1,0},          //  口 口 口
        {1,0,0,0}}, 3, 9    //  口
    },
    {{
        {0,0,0,0},          //          type 9
        {1,1,0,0},          //  口 口
        {0,1,0,0},          //     口
        {0,1,0,0}}, 3, 6    //     口
    },
    {{
        {0,0,0,0},          //          type 10
        {0,0,0,0},          //
        {0,1,1,0},          //    口口
        {1,1,0,0}}, 4, 11   //  口口
    },
    {{
        {0,0,0,0},          //          type 11
        {1,0,0,0},          //  口
        {1,1,0,0},          //  口口
        {0,1,0,0}}, 4, 10   //    口
    },
    {{
        {0,0,0,0},          //          type 12
        {0,0,0,0},          //
        {1,1,0,0},          //  口口
        {0,1,1,0}}, 5, 13   //    口口
    },
    {{
        {0,0,0,0},          //          type 13
        {0,1,0,0},          //    口
        {1,1,0,0},          //  口口
        {1,0,0,0}}, 5, 12   //  口
    },
    
    {{
        {0,0,0,0},          //          type 14
        {0,0,0,0},          //
        {0,1,0,0},          //    口
        {1,1,1,0}}, 6, 15   //  口口口
    },
    {{
        {0,0,0,0},          //          type 15
        {1,0,0,0},          //  口
        {1,1,0,0},          //  口口
        {1,0,0,0}}, 6, 16   //  口
    },
    {{
        {0,0,0,0},          //          type 16
        {0,0,0,0},          //
        {1,1,1,0},          //  口口口
        {0,1,0,0}}, 6, 17   //    口
    },
    {{
        {0,0,0,0},          //          type 17
        {0,1,0,0},          //    口
        {1,1,0,0},          //  口口
        {0,1,0,0}}, 6, 14   //    口
    },
    {{
        {0,0,0,0},          //          type 18
        {0,0,0,0},          //
        {1,1,0,0},          //  口口
        {1,1,0,0}}, 1, 18   //  口口
    },
};

HelloWorld::HelloWorld()
: m_panle_bg(nullptr)
, m_cur_type(-1)
, m_next_type(-1)
, m_cur_row(-1)
, m_cur_col(-1)
, m_max_row(-1)
, delay_time(1.0)
{
    for (int row = 0; row < ROW; row++)
    {
        for (int col = 0; col < COL; col++)
        {
            m_num_map[row][col].var = 0;
            m_num_map[row][col].color = 0;
            m_sprite_map[row][col] = nullptr;
        }
    }
}

HelloWorld::~HelloWorld()
{
}

Scene* HelloWorld::createScene()
{
    auto scene = Scene::create();
    auto layer = HelloWorld::create();
    scene->addChild(layer);
    return scene;
}

bool HelloWorld::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
    Size win_size = Director::getInstance()->getWinSize();
    auto game_bg = Sprite::create("scene_bg.jpg");
    addChild(game_bg);
    game_bg->setPosition(win_size/2);

    m_panle_bg = Sprite::create("layer_bg.png");
    addChild(m_panle_bg);
    m_panle_bg->setPosition(win_size.width/2,win_size.height/2);

    for (int row = 0; row < ROW; row++)
    {
        for (int col = 0; col < COL; col++)
        {
            m_sprite_map[row][col] = Sprite::create("0.png");
            m_sprite_map[row][col]->setPosition(START_X + col * CELL_SIZE, START_Y + row * CELL_SIZE);
            m_sprite_map[row][col]->setScale(SCALE);
            m_panle_bg->addChild(m_sprite_map[row][col]);
        }
    }
    
    reStart();
    
    auto btn_restart = ui::Button::create("btn_rorate.png");
    btn_restart->addTouchEventListener(CC_CALLBACK_2(HelloWorld::touchButtonAction, this));
    addChild(btn_restart,1,11);
    btn_restart->setPosition(Vec2(70,win_size.height - 100));
    
    auto btn_rorate = ui::Button::create("btn_rorate.png");
    btn_rorate->addTouchEventListener(CC_CALLBACK_2(HelloWorld::touchButtonAction, this));
    addChild(btn_rorate,1,10);
    btn_rorate->setPosition(Vec2(70,250));
    
    auto btn_left = ControlButton::create(ui::Scale9Sprite::create("btn_left.png"));
    addChild(btn_left,10,100);
    btn_left->setPosition(Vec2(70,100));
    btn_left->addTargetWithActionForControlEvents(this, cccontrol_selector(HelloWorld::touchAction),
                                                  Control::EventType::TOUCH_DOWN
                                                  | Control::EventType::TOUCH_UP_INSIDE
                                                  | Control::EventType::TOUCH_UP_OUTSIDE
                                                  | Control::EventType::TOUCH_CANCEL
                                                  | Control::EventType::DRAG_OUTSIDE);
    auto btn_right = ControlButton::create(ui::Scale9Sprite::create("btn_right.png"));
    btn_right->setPosition(Vec2(win_size.width - 70, 100));
    addChild(btn_right,20,101);
    btn_right->addTargetWithActionForControlEvents(this, cccontrol_selector(HelloWorld::touchAction),
                                                   Control::EventType::TOUCH_DOWN
                                                   | Control::EventType::TOUCH_UP_INSIDE
                                                   | Control::EventType::TOUCH_UP_OUTSIDE
                                                   | Control::EventType::TOUCH_CANCEL
                                                   | Control::EventType::DRAG_OUTSIDE);

    auto btn_down = ControlButton::create(ui::Scale9Sprite::create("btn_down.png"));
    btn_down->setPosition(Vec2(win_size.width - 70,250));
    addChild(btn_down,30,102);
    btn_down->addTargetWithActionForControlEvents(this, cccontrol_selector(HelloWorld::touchAction),
                                                  Control::EventType::TOUCH_DOWN
                                                  | Control::EventType::TOUCH_UP_INSIDE
                                                  | Control::EventType::TOUCH_UP_OUTSIDE
                                                  | Control::EventType::TOUCH_CANCEL
                                                  | Control::EventType::DRAG_OUTSIDE);
    

    
    
    return true;
}

void HelloWorld::touchButtonAction(Ref *pSender, ui::Widget::TouchEventType type)
{
    int tag = static_cast<Node*>(pSender)->getTag();
    if (type == ui::Widget::TouchEventType::BEGAN)
    {
        if (tag == 10)
        {
            updateNextType();
        }
        else if (tag == 11)
        {
            reStart();
        }
    }
}

void HelloWorld::touchAction(Ref *pSender, cocos2d::extension::Control::EventType type)
{
    int tag = static_cast<Node*>(pSender)->getTag();
    if (type == ControlButton::EventType::TOUCH_DOWN)
    {
        switch (tag)
        {
            case 100:
                schedule(schedule_selector(HelloWorld::updateLeft), 0.1);
                break;
            case 101:
                schedule(schedule_selector(HelloWorld::updateRight), 0.1);
                break;
            case 102:
                unschedule(schedule_selector(HelloWorld::update));
                schedule(schedule_selector(HelloWorld::touchDownCallBack), 0.03);
                break;
            default:
                break;
        }
    }
    else if (type == ControlButton::EventType::TOUCH_UP_INSIDE)
    {
        switch (tag)
        {
            case 100:
                updateLeft(0);
                break;
            case 101:
                updateRight(0);
                break;
            case 102:
                updateDown(0);
                break;
            default:
                break;
        }
    }
    if (type == ControlButton::EventType::TOUCH_UP_INSIDE
        ||type == ControlButton::EventType::TOUCH_UP_OUTSIDE
        ||type == ControlButton::EventType::TOUCH_CANCEL
        ||type == ControlButton::EventType::DRAG_OUTSIDE)
    {
        switch (tag)
        {
            case 100:
                unschedule(schedule_selector(HelloWorld::updateLeft));
                break;
            case 101:
                unschedule(schedule_selector(HelloWorld::updateRight));
                break;
            case 102:
                unschedule(schedule_selector(HelloWorld::touchDownCallBack));
                if (!isScheduled(schedule_selector(HelloWorld::updateDown)))
                {
                    schedule(schedule_selector(HelloWorld::updateDown), delay_time);
                }
                break;
            default:
                break;
        }
    }
    switch (type)
    {
        case ControlButton::EventType::TOUCH_DOWN:
            CCLOG("TOUCH_DOWN..");
            break;
        case ControlButton::EventType::TOUCH_UP_INSIDE:
            CCLOG("TOUCH_UP_INSIDE..");
            break;
        case ControlButton::EventType::TOUCH_UP_OUTSIDE:
            CCLOG("TOUCH_UP_OUTSIDE..");
            break;
        case ControlButton::EventType::TOUCH_CANCEL:
            CCLOG("TOUCH_CANCEL..");
            break;
        case ControlButton::EventType::DRAG_OUTSIDE:
            CCLOG("DRAG_OUTSIDE..");
            break;
        default:
            break;
    }
}

void HelloWorld::touchDownCallBack(float dt)
{
    updateDown(0);
}

void HelloWorld::newTetris()
{
    switch (m_cur_type)
    {
        case 0:
            m_max_row = MAX(m_max_row,m_cur_row + 3);
            break;
        case 1:
            m_max_row = MAX(m_max_row,m_cur_row);
            break;
        case 2:
        case 4:
        case 6:
        case 8:
        case 10:
        case 12:
        case 14:
        case 16:
        case 18:
            m_max_row = MAX(m_max_row,m_cur_row + 1);
            break;
        case 3:
        case 5:
        case 7:
        case 9:
        case 11:
        case 13:
        case 15:
        case 17:
            m_max_row = MAX(m_max_row,m_cur_row + 2);
            break;
        default:
            break;
    }
    removeFullRow();
    unschedule(schedule_selector(HelloWorld::touchDownCallBack));
    m_cur_type = random(0, 18);
    m_cur_row = ROW;
    m_cur_col = 4;
    updateDown(0);
}

void HelloWorld::updateUI()
{
    char pic_name[64];
    for (int row = 0; row < ROW; row++)
    {
        for (int col = 0; col < COL; col++)
        {
            sprintf(pic_name, "%d.png",m_num_map[row][col].color);
            m_sprite_map[row][col]->setTexture(pic_name);
        }
    }
}

void HelloWorld::reStart()
{
    for (int row = 0; row < ROW; row++)
    {
        for (int col = 0; col < COL; col++)
        {
            m_num_map[row][col].var = 0;
            m_num_map[row][col].color = 0;
        }
    }
    m_cur_type = -1;
    m_max_row = -1;
    updateUI();
    newTetris();
    if(!isScheduled(schedule_selector(HelloWorld::updateDown)))
    {
        schedule(schedule_selector(HelloWorld::updateDown), delay_time);
    }
}


void HelloWorld::removeFullRow()
{
    do{
        CC_BREAK_IF(m_max_row >= ROW || m_max_row < 0);
        bool isFirst = true;
        int firstRow = -1;
        for (int row = m_cur_row; row < m_cur_row + 4; )
        {
            CC_BREAK_IF(m_cur_row >= ROW || m_cur_row < 0);
            bool bRemove = false;
            for (int col = 0; col < COL; col++)
            {
                if(!m_num_map[row][col].var)
                {
                    break;
                }
                if(col == COL - 1)
                {
                    if (isFirst)
                    {
                        firstRow = row;
                        isFirst = false;
                    }
                    bRemove = true;
                    for (int r = row; r <= m_max_row; r++)
                    {
                        for (int c = 0; c < COL ; c ++)
                        {
                            m_num_map[r][c].var = m_num_map[r + 1][c].var;
                            m_num_map[r][c].color = m_num_map[r + 1][c].color;
                        }
                    }
                }
            }
            if (!bRemove)
            {
                row++;
            }
        }
        if (!isFirst)
        {
            auto cleanRow = Sprite::create("ico_clean_row.png");
            m_panle_bg->addChild(cleanRow);
            cleanRow->setPosition(START_X + 2 * CELL_SIZE, START_Y + firstRow * CELL_SIZE);
            cleanRow->setScale(0.5f);
            cleanRow->runAction(Sequence::create(MoveBy::create(0.2f, Vec2(CELL_SIZE*8,0)),RemoveSelf::create(0.1f), NULL));
        }
        
    }while(0);
}

void HelloWorld::updateDown(float dt)
{
    do{
        m_is_down = false;
        m_game_over = false;
        if (m_cur_row <= 0)
        {
            newTetris();
            break;
        }
        switch (m_cur_type)
        {
            case 0:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var)
                {
                    if (m_cur_row > ROW - 4)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                if (m_cur_row > ROW - 4)
                {
                    for (int i = m_cur_row - 1; i < ROW; i++)
                    {
                        m_num_map[i][m_cur_col].var = 1;
                        m_num_map[i][m_cur_col].color = tetris[m_cur_type].color;
                    }
                }
                else
                {
                    m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                    m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                    m_num_map[m_cur_row + 3][m_cur_col].var = 0;
                    m_num_map[m_cur_row + 3][m_cur_col].color = 0;
                }
            }
                break;
            case 1:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 2].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 3].var)
                {
                    m_is_down = false;
                    if (m_cur_row == ROW)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 3].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                m_num_map[m_cur_row][m_cur_col + 3].var = 0;
                m_num_map[m_cur_row][m_cur_col + 3].color = 0;
            }
                break;
            case 2:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 2].var)
                {
                    if (m_cur_row >= ROW - 1)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            }
                break;
            case 3:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 1].var))
                {
                    if (m_cur_row >= ROW - 2)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                if (m_cur_row >= ROW - 2)
                {
                    for (int i = m_cur_row - 1; i < ROW; i++)
                    {
                        m_num_map[i][m_cur_col].var = 1;
                        m_num_map[i][m_cur_col].color = tetris[m_cur_type].color;
                        if(m_cur_row == ROW - 2 && i == ROW - 1)
                        {
                            m_num_map[i][m_cur_col + 1].var = 1;
                            m_num_map[i][m_cur_col + 1].color = tetris[m_cur_type].color;
                        }
                    }
                }
                else
                {
                    m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                    m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                    m_num_map[m_cur_row + 1][m_cur_col + 1].var = 1;
                    m_num_map[m_cur_row + 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                    
                    m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                    m_num_map[m_cur_row + 2][m_cur_col].color = 0;
                    m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                    m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
                }
            }
                break;
            case 4:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col + 2].var
                    ||(m_cur_row < ROW &&m_num_map[m_cur_row][m_cur_col].var)
                    ||(m_cur_row < ROW &&m_num_map[m_cur_row][m_cur_col + 1].var))
                {
                    if (m_cur_row >= ROW - 1)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 5:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 1].var)
                {
                    if (m_cur_row >= ROW - 2)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row >= ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 6:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 2].var)
                {
                    if (m_cur_row >= ROW - 1)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 7:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||(m_num_map[m_cur_row - 1][m_cur_col + 1].var))
                {
                    if (m_cur_row >= ROW - 2)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row >= ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 8:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||(m_cur_row < ROW &&m_num_map[m_cur_row][m_cur_col + 1].var)
                    ||(m_cur_row < ROW &&m_num_map[m_cur_row][m_cur_col + 2].var))
                {
                    if (m_cur_row >= ROW - 1)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 9:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col].var))
                {
                    if (m_cur_row >= ROW - 2)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                if (m_cur_row >= ROW - 2)
                {
                    for (int i = m_cur_row - 1; i < ROW; i++)
                    {
                        m_num_map[i][m_cur_col + 1].var = 1;
                        m_num_map[i][m_cur_col + 1].color = tetris[m_cur_type].color;
                        if(m_cur_row == ROW - 2 && i == ROW - 1)
                        {
                            m_num_map[i][m_cur_col].var = 1;
                            m_num_map[i][m_cur_col].color = tetris[m_cur_type].color;
                        }
                    }
                }
                else
                {
                    m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                    m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                    m_num_map[m_cur_row + 1][m_cur_col].var = 1;
                    m_num_map[m_cur_row + 1][m_cur_col].color = tetris[m_cur_type].color;
                    
                    m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                    m_num_map[m_cur_row + 2][m_cur_col].color = 0;
                    m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                    m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
                }
        }
                break;
            case 10:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||(m_cur_row < ROW && m_num_map[m_cur_row][m_cur_col + 2].var))
                {
                    if (m_cur_row >= ROW - 1)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 11:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||(m_cur_row < ROW && m_num_map[m_cur_row][m_cur_col].var))
                {
                    if (m_cur_row >= ROW - 2)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 12:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 2].var
                    ||(m_cur_row < ROW && m_num_map[m_cur_row][m_cur_col].var))
                {
                    if (m_cur_row >= ROW - 1)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
        }
                break;
            case 13:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||(m_cur_row < ROW && m_num_map[m_cur_row][m_cur_col + 1].var))
                {
                    if (m_cur_row >= ROW - 2)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 14:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 2].var)
                {
                    if (m_cur_row >= ROW - 1)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
            }
                break;
            case 15:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||(m_cur_row < ROW && m_num_map[m_cur_row][m_cur_col + 1].var))
                {
                    if (m_cur_row >= ROW - 2)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 16:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||(m_cur_row < ROW && m_num_map[m_cur_row][m_cur_col].var)
                    ||(m_cur_row < ROW && m_num_map[m_cur_row][m_cur_col + 2].var))
                {
                    if (m_cur_row >= ROW - 2)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 17:
            {
                if (m_num_map[m_cur_row - 1][m_cur_col + 1].var
                    ||(m_cur_row < ROW && m_num_map[m_cur_row][m_cur_col].var))
                {
                    if (m_cur_row >= ROW - 2)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW);
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 18:
                if (m_num_map[m_cur_row - 1][m_cur_col].var
                    ||m_num_map[m_cur_row - 1][m_cur_col + 1].var)
                {
                    if (m_cur_row >= ROW - 1)
                    {
                        m_game_over = true;
                    }
                    break;
                }
                m_is_down = true;
                m_num_map[m_cur_row - 1][m_cur_col].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row >= ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                break;
            default:
                break;
        }
        
        if (m_game_over)
        {
            this->unschedule(schedule_selector(HelloWorld::updateDown));
            log("game over");
            break;
        }
        
        if (!m_is_down)
        {
//            m_panle_bg->runAction(Sequence::create(MoveBy::create(0.1, Vec2(0,30)),
//                                                   MoveBy::create(0.1, Vec2(0,-30)),
//                                                   MoveBy::create(0.1, Vec2(0,20)),
//                                                   MoveBy::create(0.1, Vec2(0,-20)),
//                                                   NULL));
            newTetris();
            break;
        }
        
        m_cur_row--;
        updateUI();
    }while (0);

}

void HelloWorld::updateLeft(float dt)
{
    do
    {
        CC_BREAK_IF(m_cur_row == ROW);
        CC_BREAK_IF(m_cur_col < 1);
        bool b_moved = false;
        switch (m_cur_type)
        {
            case 0:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col - 1].var)
                    ||(m_cur_row < ROW - 3 && m_num_map[m_cur_row + 3][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
                m_num_map[m_cur_row + 2][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col - 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 3);
                m_num_map[m_cur_row + 3][m_cur_col].var = 0;
                m_num_map[m_cur_row + 3][m_cur_col].color = 0;
                m_num_map[m_cur_row + 3][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 3][m_cur_col - 1].color = tetris[m_cur_type].color;
            }
                break;
            case 1:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var)
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 3].var = 0;
                m_num_map[m_cur_row][m_cur_col + 3].color = 0;
            }
                break;
            case 2:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            }
                break;
            case 3:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 4:
            {
                if (m_num_map[m_cur_row][m_cur_col + 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 5:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 6:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 7:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 8:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 9:
            {
                if (m_num_map[m_cur_row][m_cur_col].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 10:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 11:
            {
                if (m_num_map[m_cur_row][m_cur_col].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 12:
            {
                if (m_num_map[m_cur_row][m_cur_col].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
            }
                break;
            case 13:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 14:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
            }
                break;
            case 15:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 16:
            {
                if (m_num_map[m_cur_row][m_cur_col].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 17:
            {
                if (m_num_map[m_cur_row][m_cur_col].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col].var = 1;
                m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 18:
            {
                if (m_num_map[m_cur_row][m_cur_col - 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col - 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
            }
                break;
            default:
                break;
        }
        if (b_moved)
        {
            m_cur_col--;
            updateUI();
        }
    }while(0);
}
void HelloWorld::updateRight(float dt)
{
    do
    {
        CC_BREAK_IF(m_cur_row == ROW);
        CC_BREAK_IF(m_cur_col >= COL - 1);
        bool b_moved = false;
        switch (m_cur_type)
        {
            case 0:
            {
                if (m_num_map[m_cur_row][m_cur_col + 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var)
                    ||(m_cur_row < ROW - 3 && m_num_map[m_cur_row + 3][m_cur_col + 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = tetris[m_cur_type].color;
                CC_BREAK_IF(m_cur_row == ROW - 3);
                m_num_map[m_cur_row + 3][m_cur_col].var = 0;
                m_num_map[m_cur_row + 3][m_cur_col].color = 0;
                m_num_map[m_cur_row + 3][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 3][m_cur_col + 1].color = tetris[m_cur_type].color;
            }
                break;
            case 1:
            {
                CC_BREAK_IF(m_cur_col >= COL - 4);
                if (m_num_map[m_cur_row][m_cur_col + 4].var)
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 4].var = 1;
                m_num_map[m_cur_row][m_cur_col + 4].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
            }
                break;
            case 2:
            {
                CC_BREAK_IF(m_cur_col >= COL - 3);
                if (m_num_map[m_cur_row][m_cur_col + 3].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            }
                break;
            case 3:
            {
                CC_BREAK_IF(m_cur_col >= COL - 2);
                if (m_num_map[m_cur_row][m_cur_col + 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 4:
            {
                CC_BREAK_IF(m_cur_col >= COL - 3);
                if (m_num_map[m_cur_row][m_cur_col + 3].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 3].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row][m_cur_col + 2].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            }
                break;
            case 5:
            {
                CC_BREAK_IF(m_cur_col >= COL - 2);
                if (m_num_map[m_cur_row][m_cur_col + 2].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 6:
            {
                CC_BREAK_IF(m_cur_col >= COL - 3);
                if (m_num_map[m_cur_row][m_cur_col + 3].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 3].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            }
                break;
            case 7:
            {
                CC_BREAK_IF(m_cur_col >= COL - 2);
                if (m_num_map[m_cur_row][m_cur_col + 2].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 1].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 8:
            {
                CC_BREAK_IF(m_cur_col >= COL - 3);
                if (m_num_map[m_cur_row][m_cur_col + 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 3].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            }
                break;
            case 9:
            {
                CC_BREAK_IF(m_cur_col >= COL - 2);
                if (m_num_map[m_cur_row][m_cur_col + 2].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 10:
            {
                CC_BREAK_IF(m_cur_col >= COL - 3);
                if (m_num_map[m_cur_row][m_cur_col + 2].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 3].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
            }
                break;
            case 11:
            {
                CC_BREAK_IF(m_cur_col >= COL - 2);
                if (m_num_map[m_cur_row][m_cur_col + 2].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 12:
            {
                CC_BREAK_IF(m_cur_col >= COL - 3);
                if (m_num_map[m_cur_row][m_cur_col + 3].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            }
                break;
            case 13:
            {
                CC_BREAK_IF(m_cur_col >= COL - 2);
                if (m_num_map[m_cur_row][m_cur_col + 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 14:
            {
                CC_BREAK_IF(m_cur_col >= COL - 3);
                if (m_num_map[m_cur_row][m_cur_col + 3].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
            }
                break;
            case 15:
            {
                CC_BREAK_IF(m_cur_col >= COL - 2);
                if (m_num_map[m_cur_row][m_cur_col + 1].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            }
                break;
            case 16:
            {
                CC_BREAK_IF(m_cur_col >= COL - 3);
                if (m_num_map[m_cur_row][m_cur_col + 2].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 3].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 3].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 3].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            }
                break;
            case 17:
            {
                CC_BREAK_IF(m_cur_col >= COL - 2);
                if (m_num_map[m_cur_row][m_cur_col + 2].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                    ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row][m_cur_col + 1].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 2);
                m_num_map[m_cur_row + 2][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 2][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
                m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
            }
                break;
            case 18:
            {
                CC_BREAK_IF(m_cur_col >= COL - 2);
                if (m_num_map[m_cur_row][m_cur_col + 2].var
                    ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var))
                {
                    break;
                }
                b_moved = true;
                m_num_map[m_cur_row][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row][m_cur_col].var = 0;
                m_num_map[m_cur_row][m_cur_col].color = 0;
                CC_BREAK_IF(m_cur_row == ROW - 1);
                m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
                m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
                m_num_map[m_cur_row + 1][m_cur_col].var = 0;
                m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            }
                break;
            default:
                break;
        }
        if (b_moved)
        {
            m_cur_col++;
            updateUI();
        }
    }while(0);
}

void HelloWorld::updateNextType()
{
    do
    {
        CC_BREAK_IF(m_cur_row == ROW);
    bool is_next_type = false;
    switch (m_cur_type)
    {
        case 0:
        {
            CC_BREAK_IF(m_cur_row == ROW - 1);
            CC_BREAK_IF(m_cur_col == 0 || m_cur_col > COL - 3);
            if (m_num_map[m_cur_row][m_cur_col - 1].var
                ||m_num_map[m_cur_row + 1][m_cur_col - 1].var
                ||m_num_map[m_cur_row + 1][m_cur_col + 1].var
                ||m_num_map[m_cur_row + 1][m_cur_col + 2].var
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 3 && m_num_map[m_cur_row + 3][m_cur_col + 1].var)
                ||(m_cur_row < ROW - 3 && m_num_map[m_cur_row + 3][m_cur_col + 2].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row + 1][m_cur_col - 1].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col - 1].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row + 1][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col + 1].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row][m_cur_col].var = 0;
            m_num_map[m_cur_row][m_cur_col].color = 0;
            m_cur_row++;
            m_cur_col--;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
        }
            break;
        case 1:
        {
            CC_BREAK_IF(m_cur_row < 1);
            if (m_num_map[m_cur_row - 1][m_cur_col].var
                ||m_num_map[m_cur_row - 1][m_cur_col + 1].var
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 1].var)
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 3].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            
            m_num_map[m_cur_row - 1][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row - 1][m_cur_col + 1].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row][m_cur_col].var = 0;
            m_num_map[m_cur_row][m_cur_col].color = 0;
            m_num_map[m_cur_row][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row][m_cur_col + 2].color = 0;
            m_num_map[m_cur_row][m_cur_col + 3].var = 0;
            m_num_map[m_cur_row][m_cur_col + 3].color = 0;
            m_cur_row--;
            m_cur_col++;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 3);
            m_num_map[m_cur_row + 3][m_cur_col].var = 1;
            m_num_map[m_cur_row + 3][m_cur_col].color = tetris[m_cur_type].color;
        }
            break;
        case 2:
        {
            if ((m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            
            m_num_map[m_cur_row][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row][m_cur_col + 1].color = 0;
            m_num_map[m_cur_row][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row][m_cur_col + 2].color = 0;
            CC_BREAK_IF(m_cur_row >= ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = tetris[m_cur_type].color;
        }
            break;
        case 3:
        {
            CC_BREAK_IF(m_cur_col > COL - 3);
            if (m_num_map[m_cur_row][m_cur_col + 2].var
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 1].var)
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            
            m_num_map[m_cur_row][m_cur_col].var = 0;
            m_num_map[m_cur_row][m_cur_col].color = 0;
            m_num_map[m_cur_row][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col + 1].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
        }
            break;
        case 4:
        {
            if (m_num_map[m_cur_row][m_cur_col].var
                ||m_num_map[m_cur_row][m_cur_col + 1].var
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            
            m_num_map[m_cur_row][m_cur_col].var = 1;
            m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row][m_cur_col + 2].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = tetris[m_cur_type].color;
        }
            break;
        case 5:
        {
            CC_BREAK_IF(m_cur_col > COL - 3);
            if (m_num_map[m_cur_row][m_cur_col + 2].var
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col].var)
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            
            m_num_map[m_cur_row][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
        }
            break;
        case 6:
        {
            if ((m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row][m_cur_col + 2].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            m_num_map[m_cur_row + 1][m_cur_col].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col].color = tetris[m_cur_type].color;
        }
            break;
        case 7:
        {
            CC_BREAK_IF(m_cur_col > COL - 3);
            if ((m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 1].var)
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row][m_cur_col + 1].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col + 1].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col].color = 0;
        }
            break;
        case 8:
        {
            if (m_num_map[m_cur_row][m_cur_col + 1].var
                ||m_num_map[m_cur_row][m_cur_col + 2].var
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col].var = 0;
            m_num_map[m_cur_row][m_cur_col].color = 0;
            m_num_map[m_cur_row][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = tetris[m_cur_type].color;
        }
            break;
        case 9:
        {
            CC_BREAK_IF(m_cur_col > COL - 3);
            if (m_num_map[m_cur_row][m_cur_col].var
                ||m_num_map[m_cur_row][m_cur_col + 2].var
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col].var = 1;
            m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 1].color = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col].color = 0;
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
        }
            break;
        case 10:
        {
            if ((m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col].var = 0;
            m_num_map[m_cur_row][m_cur_col].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col].color = tetris[m_cur_type].color;
        }
            break;
        case 11:
        {
            CC_BREAK_IF(m_cur_col > COL - 3);
            if (m_num_map[m_cur_row][m_cur_col].var
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col].var = 1;
            m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col].color = 0;
        }
            break;
        case 12:
        {
            if (m_num_map[m_cur_row][m_cur_col].var
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col].var = 1;
            m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row][m_cur_col + 1].color = 0;
            m_num_map[m_cur_row][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row][m_cur_col + 2].color = 0;
            CC_BREAK_IF(m_cur_row >= ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = tetris[m_cur_type].color;
        }
            break;
        case 13:
        {
            CC_BREAK_IF(m_cur_col > COL - 3);
            if (m_num_map[m_cur_row][m_cur_col + 1].var
                ||m_num_map[m_cur_row][m_cur_col + 2].var
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col].var = 0;
            m_num_map[m_cur_row][m_cur_col].color = 0;
            m_num_map[m_cur_row][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row >= ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
        }
            break;
        case 14:
        {
            if ((m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row][m_cur_col + 1].color = 0;
            m_num_map[m_cur_row][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row][m_cur_col + 2].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col].color = tetris[m_cur_type].color;
        }
            break;
        case 15:
        {
            CC_BREAK_IF(m_cur_col > COL - 3);
            if (m_num_map[m_cur_row][m_cur_col + 1].var
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col].var = 0;
            m_num_map[m_cur_row][m_cur_col].color = 0;
            m_num_map[m_cur_row][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row][m_cur_col + 1].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col].color = 0;
        }
            break;
        case 16:
        {
            if (m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 1].var)
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col + 2].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col + 2].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 1;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = tetris[m_cur_type].color;
        }
            break;
        case 17:
        {
            CC_BREAK_IF(m_cur_col > COL - 3);
            if (m_num_map[m_cur_row][m_cur_col].var
                ||m_num_map[m_cur_row][m_cur_col + 2].var
                ||(m_cur_row < ROW - 1 && m_num_map[m_cur_row + 1][m_cur_col + 2].var)
                ||(m_cur_row < ROW - 2 && m_num_map[m_cur_row + 2][m_cur_col + 2].var))
            {
                break;
            }
            is_next_type = true;
            m_cur_type = tetris[m_cur_type].next_type;
            m_num_map[m_cur_row][m_cur_col].var = 1;
            m_num_map[m_cur_row][m_cur_col].color = tetris[m_cur_type].color;
            m_num_map[m_cur_row][m_cur_col + 2].var = 1;
            m_num_map[m_cur_row][m_cur_col + 2].color = tetris[m_cur_type].color;
            CC_BREAK_IF(m_cur_row == ROW - 1);
            m_num_map[m_cur_row + 1][m_cur_col].var = 0;
            m_num_map[m_cur_row + 1][m_cur_col].color = 0;
            CC_BREAK_IF(m_cur_row == ROW - 2);
            m_num_map[m_cur_row + 2][m_cur_col + 1].var = 0;
            m_num_map[m_cur_row + 2][m_cur_col + 1].color = 0;
        }
            break;
        default:
            break;
    }
    if (is_next_type)
    {
        updateUI();
    }
}while(0);
}

