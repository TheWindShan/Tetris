//
//  GemeDefine.h
//  Tetris
//
//  Created by fengyi on 16/3/10.
//
//

#ifndef GemeDefine_h
#define GemeDefine_h

#define CELL_TYPE 19
#define CELL_SIZE 40
#define START_X 63
#define START_Y 86
#define ROW 20
#define COL 10

#endif /* GemeDefine_h */
